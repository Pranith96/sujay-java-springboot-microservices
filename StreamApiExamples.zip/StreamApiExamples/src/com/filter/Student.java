package com.filter;

public class Student {

	private Integer id;
	private String studentName;
	private String status;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Student(Integer id, String studentName, String status) {
		this.id = id;
		this.studentName = studentName;
		this.status = status;
	}

	public Student() {
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", studentName=" + studentName + ", status=" + status + "]";
	}

}
