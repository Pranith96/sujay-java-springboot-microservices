
public class AdditionalImpl implements Addition {

	@Override
	public void add() {
		System.out.println("Hi Add");
	}

}
