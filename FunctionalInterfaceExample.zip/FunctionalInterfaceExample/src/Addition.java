
public interface Addition {
	public void add();
}
